//Carlos enrique cordero Linares cl18030
#include<iostream>
#include<stack>
#include <string.h>
using namespace std;

struct Nodo{
	int cl_due;
	char cl_fecha[10];
	char cl_activ[20];
	float cl_nota;
	char cl_revis;
};

void m_centerstring(string cl_s)
{ //codigo obtenido de: https://www.dreamincode.net/forums/topic/13749-center-text-with-cout/
   int cl_l=strlen(cl_s.c_str());
   int cl_pos=(int)((115-cl_l)/2);
   for(int i=0;i<=cl_pos;i++)
    cout<<" ";
   
   cout<<cl_s;
}

void m_clear(bool &cl_rep){ //Limpia la variable en caso de que el tipo de dato sea el incorrecto	
	if(cin.fail()) //si al ingresar el dato da error
	{
		cl_rep = true;
		cin.clear(); //limpia la variable para que pueda ser ingresada nuevamente
		cin.ignore();
		cout << "Ingrese un valor valido\n\n";
	}
	else
		cl_rep = false; //el dato no es erroneo
}

void m_menu(){
	m_centerstring("----------------------------------------------\n");
	m_centerstring("Que accion desea realizar:\n");
	m_centerstring("1-Ingresar examen\n");
	m_centerstring("2-Eliminar examen\n");
	m_centerstring("3-Listar examenes\n");
	m_centerstring("4-Buscar examen\n");
	m_centerstring("5-Ver promedio, la nota mayor y la menor\n");
	m_centerstring("6-Salir\n");
	m_centerstring("----------------------------------------------\n");
	cout << "-->";
}


int main(){
	stack<Nodo> pila_nodo;
	Nodo aux_nodo;
	Nodo *puntero_nodo;
	int cl_op;
	int cl_busc;
	int cl_cont;
	bool cl_rep;
	int cl_due;
	char cl_fecha[10];
	char cl_activ[20];
	float cl_nota;
	char cl_revis;
	float cl_suma;
	float cl_max;
	
	do{
	m_menu();
	cin >> cl_op;
	
	switch(cl_op) {
		case 1:
			do{
				cout << "Ingrese su due: ";
				cin >> aux_nodo.cl_due;
				for(int i = 0; i < pila_nodo.size(); i++){
					
					if(aux_nodo.cl_due == puntero_nodo->cl_due){
					cl_rep = true;		
					}		
				}
				m_clear(cl_rep);}while(cl_rep);
			do{
				cout << "Ingrese la fecha del examen (dd/mm/aa): ";
				cin >> aux_nodo.cl_fecha;	
				m_clear(cl_rep);	}while(cl_rep);
			do{
				cout << "Ingrese el tipo de actividad: ";
				cin >> aux_nodo.cl_activ;
				m_clear(cl_rep);	}while(cl_rep);
			do{
				cout << "Ingrese la nota de la actividad: ";
				cin >> aux_nodo.cl_nota;
				m_clear(cl_rep);	}while(cl_rep);
			do{
				cout << "Ya esta revisado? (s,n): ";
				cin >> aux_nodo.cl_revis;
				m_clear(cl_rep);	}while(cl_rep);
				pila_nodo.push(aux_nodo);
				
			break;
			
		case 2:
			if(!pila_nodo.empty()){
				pila_nodo.pop();
				cout << "El dato ha sido eliminado...\n";
			}
			else{
				cout << "Vacio \n";
			}
			break;
	
		case 3:
			if(!pila_nodo.empty()){
			puntero_nodo = &pila_nodo.top();
			while( cl_cont < pila_nodo.size() ){ //mientras el contador sea menor a el tama�o de la pila
			aux_nodo = *puntero_nodo;//asigna el valor de la ubicacion a un auxiliar
			cout << aux_nodo.cl_due << "\n";//imprime el valor
			cout << aux_nodo.cl_fecha << "\n";
			cout << aux_nodo.cl_activ << "\n";
			cout << aux_nodo.cl_nota << "\n";
			cout << aux_nodo.cl_revis << "\n";
			puntero_nodo--;//reduce su posicion en 1
			cl_cont++;//aumenta el conteo de posiciones recorridas
			cout << endl << endl;
			}}
			else{
				cout << "Vacio \n";
			}
			break;
	
		case 4:
			puntero_nodo = &pila_nodo.top();
			cin >> cl_busc;
			for(int i = 0; i < pila_nodo.size(); i++){
				
				if(cl_busc == puntero_nodo->cl_due){
					cout << puntero_nodo->cl_activ << endl;
					cout << puntero_nodo->cl_due << endl;
					cout << puntero_nodo->cl_fecha << endl;
					cout << puntero_nodo->cl_nota << endl;
					cout << puntero_nodo->cl_revis << endl << endl << endl;	
				}
				puntero_nodo--;
			}
			break;
	
		case 5:
			puntero_nodo = &pila_nodo.top();
			cl_max = puntero_nodo->cl_nota;
			while( cl_cont < pila_nodo.size() ){ //mientras el contador sea menor a el tama�o de la pila
			aux_nodo = *puntero_nodo;//asigna el valor de la ubicacion a un auxiliar
			cl_suma = cl_suma + puntero_nodo->cl_nota;
			puntero_nodo--;//reduce su posicion en 1
			cl_cont++;//aumenta el conteo de posiciones recorridas
			
			if(cl_max < puntero_nodo->cl_nota)
				cl_max = puntero_nodo->cl_nota;
			
			}
			cl_suma = cl_suma / cl_cont;
			cout << "El promedio es: " << cl_suma << endl;
			cout << "El mayor es: " << cl_max << endl;
			
			
			break;
		
		case 6:
			return 0;
		
		default:
			m_centerstring("Ingrese un valor dentro del rango\n");
			cin.clear();
			cin.ignore();
	}
	cl_cont = 0;
	cin.get(); cin.get();
	system("cls");
	}while(true);
}

//problemas con el mostrar, arrelar un poco y optimizar
