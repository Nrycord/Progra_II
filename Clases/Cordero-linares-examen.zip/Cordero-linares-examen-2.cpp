//Carlos enrique cordero Linares cl18030

#include<iostream>
#include<stack>
#include <string.h>
using namespace std;

struct Nodo{
	int cl_cod;
	char cl_vehiculo[20];
	int cl_hora;
	float cl_costoph;
};

void m_centerstring(string cl_s)
{ //codigo obtenido de: https://www.dreamincode.net/forums/topic/13749-center-text-with-cout/
   int cl_l=strlen(cl_s.c_str());
   int cl_pos=(int)((115-cl_l)/2);
   for(int i=0;i<=cl_pos;i++)
    cout<<" ";
   
   cout<<cl_s;
}

void m_clear(bool &cl_rep){ //Limpia la variable en caso de que el tipo de dato sea el incorrecto	
	if(cin.fail()) //si al ingresar el dato da error
	{
		cl_rep = true;
		cin.clear(); //limpia la variable para que pueda ser ingresada nuevamente
		cin.ignore();
		cout << "Ingrese un valor valido\n\n";
	}
	else
		cl_rep = false; //el dato no es erroneo
}

void m_menu(){
	m_centerstring("----------------------------------------------\n");
	m_centerstring("Que accion desea realizar:\n");
	m_centerstring("1-Agregar vehiculo\n"); //mostrar cuantos hay hasta el momento
	m_centerstring("2-Eliminar vehiculo\n");
	m_centerstring("3-Listar vehiculos\n");
	m_centerstring("4-Buscar vehiculo\n");
	m_centerstring("5-Total de prestamos y promedio de ingreso\n");
	m_centerstring("6-Salir\n");
	m_centerstring("----------------------------------------------\n");
	cout << "-->";
}


/*do{
	clear(rep);	}while(rep); //verificacion de el ingreso de datos*/
int main(){
	stack<Nodo> pila_nodo;
	Nodo aux_nodo;
	Nodo *puntero_nodo;
	int cl_op;
	int cl_busc;
	int cl_cont;
	bool cl_rep;
	int cl_naut = 0;;
	int cl_cod;
	char cl_vehiculo[20];
	int cl_hora;
	float cl_costoph;
	
	float cl_suma;
	float cl_max;
	float cl_min;
	
	
	do{
		m_menu();
		cin >> cl_op;
	
	switch(cl_op) {
		case 1:
			
			cout << "Hay " << cl_naut << " rentados." << endl;
			
			do{
				cout << "Ingrese: ";
				cin >> aux_nodo.cl_cod;
				for(int i = 0; i < pila_nodo.size(); i++){
					
					if(aux_nodo.cl_cod == puntero_nodo->cl_cod){
					cl_rep = true;		
					}		
				}
				m_clear(cl_rep);}while(cl_rep);
			do{
				cout << "Ingrese: ";
				cin >> aux_nodo.cl_vehiculo;	
				m_clear(cl_rep);	}while(cl_rep);
			do{
				cout << "Ingrese: ";
				cin >> aux_nodo.cl_hora;
				m_clear(cl_rep);	}while(cl_rep);
			do{
				cout << "Ingrese: ";
				cin >> aux_nodo.cl_costoph;
				m_clear(cl_rep);	}while(cl_rep);
				pila_nodo.push(aux_nodo);
				cl_naut++;
			break;
			
		case 2:
			if(!pila_nodo.empty()){
				pila_nodo.pop();
				puntero_nodo = &pila_nodo.top();
				cl_naut--;
				cout << "El dato ha sido eliminado...\n";
			}
			else{
				cout << "Vacio \n";
			}
			break;
	
		case 3:
			if(!pila_nodo.empty()){
			puntero_nodo = &pila_nodo.top();
			while( cl_cont < pila_nodo.size() ){ //mientras el contador sea menor a el tama�o de la pila
			aux_nodo = *puntero_nodo;//asigna el valor de la ubicacion a un auxiliar
			cout << aux_nodo.cl_cod << "\n";//imprime el valor
			cout << aux_nodo.cl_vehiculo << "\n";
			cout << aux_nodo.cl_hora << "\n";
			cout << aux_nodo.cl_costoph << "\n";
			puntero_nodo--;//reduce su posicion en 1
			cl_cont++;//aumenta el conteo de posiciones recorridas
			cout << endl << endl;
			}
			}else{
				cout << "Vacio \n";
			}
			break;
	
		case 4:
			if(!pila_nodo.empty()){
			puntero_nodo = &pila_nodo.top();
			cin >> cl_busc;
			for(int i = 0; i < pila_nodo.size();){
				
				if(cl_busc == puntero_nodo->cl_cod){
					cout << puntero_nodo->cl_cod << "\n";
					cout << puntero_nodo->cl_vehiculo << "\n";
					cout << puntero_nodo->cl_hora << "\n";
					cout << puntero_nodo->cl_costoph << endl << endl;	
					break;
				}
				puntero_nodo--;
				i++;
			}
			}else{
				cout << "Vacio \n";
			}
			break;
	
		case 5:
			if(!pila_nodo.empty()){
			
			puntero_nodo = &pila_nodo.top();
			while( cl_cont < pila_nodo.size() ){ //mientras el contador sea menor a el tama�o de la pila
			aux_nodo = *puntero_nodo;//asigna el valor de la ubicacion a un auxiliar
			cl_suma = cl_suma + (puntero_nodo->cl_costoph * puntero_nodo->cl_hora);
			puntero_nodo--;//reduce su posicion en 1
			cl_cont++;//aumenta el conteo de posiciones recorridas
			}
			cl_suma = cl_suma / cl_cont;
			cout << "Hay un total de " << cl_cont << " autos.\n";
			cout << "El promedio es: " << cl_suma << endl;			
			}else{
				cout << "Vacio \n";
			}
			break;
		
		case 6:
			return 0;
		
		default:
			m_centerstring("Ingrese un valor dentro del rango\n");
			cin.clear();
			cin.ignore();
	}
	cl_cont = 0;
	cout << "\nPresione cualquier tecla para continuar...\n";
	cin.get(); cin.get();
	system("cls");
	}while(true);
}

